import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FileSpreadsheet, Mic, Share2, Table as TableIcon, PresentationIcon } from "lucide-react";
import { SpreadsheetToolbar } from "@/components/spreadsheet/SpreadsheetToolbar";
import { SpreadsheetGrid } from "@/components/spreadsheet/SpreadsheetGrid";
import { SlidesToolbar } from "@/components/slides/SlidesToolbar";
import { SlideEditor } from "@/components/slides/SlideEditor";

function App() {
  // Spreadsheet state
  const [spreadsheetData, setSpreadsheetData] = useState<Record<string, any>[]>([]);
  const spreadsheetHeaders = ['A', 'B', 'C', 'D', 'E', 'F'];
  const spreadsheetRows = 15;

  // Slides state
  const [slides, setSlides] = useState([
    { id: 1, content: [] },
    { id: 2, content: [] },
    { id: 3, content: [] },
  ]);
  const [selectedSlide, setSelectedSlide] = useState<number | null>(null);

  // Spreadsheet handlers
  const handleCellChange = (row: number, col: number, value: string) => {
    const newData = [...spreadsheetData];
    if (!newData[row]) newData[row] = {};
    newData[row][spreadsheetHeaders[col]] = value;
    setSpreadsheetData(newData);
  };

  const handleFormatChange = (format: string) => {
    console.log("Format changed:", format);
  };

  const handleFunctionInsert = () => {
    console.log("Insert function");
  };

  const handleFilter = () => {
    console.log("Apply filter");
  };

  const handleSort = () => {
    console.log("Sort data");
  };

  const handleChartInsert = () => {
    console.log("Insert chart");
  };

  // Slides handlers
  const handleNewSlide = () => {
    setSlides([...slides, { id: slides.length + 1, content: [] }]);
  };

  const handleSlideContentChange = (slideId: number, content: any) => {
    const newSlides = slides.map((slide) =>
      slide.id === slideId ? { ...slide, content } : slide
    );
    setSlides(newSlides);
  };

  const handleInsertElement = (type: string) => {
    if (selectedSlide === null) return;
    const newSlides = [...slides];
    newSlides[selectedSlide].content.push({ type, data: "" });
    setSlides(newSlides);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="flex h-16 items-center px-4">
          <FileSpreadsheet className="h-6 w-6 text-primary mr-2" />
          <h1 className="text-xl font-semibold">Course Studio Pro</h1>
          <div className="ml-auto flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
            <Button variant="default" size="sm">
              <Mic className="h-4 w-4 mr-2" />
              Start Recording
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="spreadsheet" className="h-[calc(100vh-4rem)]">
        <div className="border-b px-4 py-2">
          <TabsList className="h-9 items-center">
            <TabsTrigger value="spreadsheet" className="flex items-center px-3">
              <TableIcon className="h-4 w-4 mr-2" />
              Spreadsheet
            </TabsTrigger>
            <TabsTrigger value="slides" className="flex items-center px-3">
              <PresentationIcon className="h-4 w-4 mr-2" />
              Slides
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="spreadsheet" className="h-full p-0">
          <div className="flex flex-col h-full">
            <SpreadsheetToolbar
              onFormatChange={handleFormatChange}
              onFunctionInsert={handleFunctionInsert}
              onFilter={handleFilter}
              onSort={handleSort}
              onChartInsert={handleChartInsert}
            />
            <SpreadsheetGrid
              headers={spreadsheetHeaders}
              rows={spreadsheetRows}
              data={spreadsheetData}
              onCellChange={handleCellChange}
            />
          </div>
        </TabsContent>

        <TabsContent value="slides" className="h-full p-0">
          <div className="flex flex-col h-full">
            <SlidesToolbar
              onInsertElement={handleInsertElement}
              onChangeLayout={() => console.log("Change layout")}
              onChangeTheme={() => console.log("Change theme")}
              onStartPresentation={() => console.log("Start presentation")}
            />
            <SlideEditor
              slides={slides}
              selectedSlide={selectedSlide}
              onSlideSelect={setSelectedSlide}
              onNewSlide={handleNewSlide}
              onSlideContentChange={handleSlideContentChange}
            />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default App;